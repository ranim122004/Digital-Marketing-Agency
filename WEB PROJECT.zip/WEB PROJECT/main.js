$(document).ready(function() {
    // Add a click event listener to the button
    $('#btn1').on('click', function() {
      // Change the location to the desired HTML page
      window.location.href = 'login.html';
    });
    $('.card-button').on('click', function(){
        window.location.href = 'services.html'
    });
    $.getJSON('data.json', function (data) {
      // Display first set of categories
      displayCategories(data.categories, '#services-container');

      // Display mission
      $('#mission-image').attr('src', data.mission.image);

      // Display second set of categories
      displayCategories(data.secondCategories, '#second-services-container');

      // Display second mission
      $('#second-mission-image').attr('src', data.secondMission.image);

      // Display third set of categories
      displayCategories(data.thirdCategories, '#third-services-container');

    
  });

  function displayCategories(categories, containerId) {
      var container = $(containerId);

      $.each(categories, function (index, category) {
          var card = $('<div class="card">' +
              '<div class="card-inner">' +
              '<div class="card-front" style="display: flex;">' +
              '<img src="' + category.image + '" height="100px" width="100px">' +
              '<p>' + category.title + '</p>' +
              '</div>' +
              '<div class="card-back">' +
              '<p>' + category.description + '</p>' +
              '</div>' +
              '</div>' +
              '</div>');

          container.append(card);
      });
  }
  
});
  